*PADS-LIBRARY-PART-TYPES-V9*

MT48LC64M8A2P-75_C SOP80P1176X120-54N I ANA 7 1 0 0 0
TIMESTAMP 2026.03.21.14.05.35
"Mouser Part Number" 913-MT48LC64M8A2P75C
"Mouser Price/Stock" https://www.mouser.com/Search/Refine.aspx?Keyword=913-MT48LC64M8A2P75C
"Manufacturer_Name" Alliance Memory
"Manufacturer_Part_Number" MT48LC64M8A2P-75:C
"Description" DRAM 512Mb, 3.3v, 133Mhz 64M x 8 SDR
"Datasheet Link" https://componentsearchengine.com/Datasheets/1/MT48LC64M8A2P-75_C.pdf
"Geometry.Height" 1.2mm
GATE 1 54 0
MT48LC64M8A2P-75_C
1 0 U VDD_1
2 0 U DQ0
3 0 U VDDQ_1
4 0 U NC_1
5 0 U DQ1
6 0 U VSSQ_1
7 0 U NC_2
8 0 U DQ2
9 0 U VDDQ_2
10 0 U NC_3
11 0 U DQ3
12 0 U VSSQ_2
13 0 U NC_4
14 0 U VDD_2
15 0 U NC_5
16 0 U WE#
17 0 U CAS#
18 0 U RAS#
19 0 U CS#
20 0 U BA0
21 0 U BA1
22 0 U A10
23 0 U A0
24 0 U A1
25 0 U A2
26 0 U A3
27 0 U VDD_3
54 0 U VSS_3
53 0 U DQ7
52 0 U VSSQ_4
51 0 U NC_10
50 0 U DQ6
49 0 U VDDQ_4
48 0 U NC_9
47 0 U DQ5
46 0 U VSSQ_3
45 0 U NC_8
44 0 U DQ4
43 0 U VDDQ_3
42 0 U NC_7
41 0 U VSS_2
40 0 U NC_6
39 0 U DQM
38 0 U CLK
37 0 U CKE
36 0 U A12
35 0 U A11
34 0 U A9
33 0 U A8
32 0 U A7
31 0 U A6
30 0 U A5
29 0 U A4
28 0 U VSS_1

*END*
*REMARK* SamacSys ECAD Model
950972/1218056/2.50/54/3/Integrated Circuit
