PCBNEW-LibModule-V1  2026-03-09 00:13:19
# encoding utf-8
Units mm
$INDEX
BGA324C80P18X18_1500X1500X150
$EndINDEX
$MODULE BGA324C80P18X18_1500X1500X150
Po 0 0 0 15 69ae109f 00000000 ~~
Li BGA324C80P18X18_1500X1500X150
Cd (CSG324)
Kw Integrated Circuit
Sc 0
At SMD
AR 
Op 0 0 0
T0 0 0 1.27 1.27 0 0.254 N V 21 N "IC**"
T1 0 0 1.27 1.27 0 0.254 N I 21 N "BGA324C80P18X18_1500X1500X150"
DS -8.5 -8.5 8.5 -8.5 0.05 24
DS 8.5 -8.5 8.5 8.5 0.05 24
DS 8.5 8.5 -8.5 8.5 0.05 24
DS -8.5 8.5 -8.5 -8.5 0.05 24
DS -7.5 -7.5 7.5 -7.5 0.1 24
DS 7.5 -7.5 7.5 7.5 0.1 24
DS 7.5 7.5 -7.5 7.5 0.1 24
DS -7.5 7.5 -7.5 -7.5 0.1 24
DS -7.5 -3.75 -3.75 -7.5 0.1 24
DS -6.8 -7.5 7.5 -7.5 0.2 21
DS 7.5 -7.5 7.5 7.5 0.2 21
DS 7.5 7.5 -7.5 7.5 0.2 21
DS -7.5 7.5 -7.5 -6.8 0.2 21
DS -7.5 -6.8 -6.8 -7.5 0.2 21
DC -7.5 -7.5 -7.4 -7.5 0.254 21
$PAD
Po -6.8 -6.8
Sh "A1" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6 -6.8
Sh "A2" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.2 -6.8
Sh "A3" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.4 -6.8
Sh "A4" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.6 -6.8
Sh "A5" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.8 -6.8
Sh "A6" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2 -6.8
Sh "A7" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.2 -6.8
Sh "A8" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.4 -6.8
Sh "A9" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.4 -6.8
Sh "A10" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.2 -6.8
Sh "A11" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2 -6.8
Sh "A12" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.8 -6.8
Sh "A13" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.6 -6.8
Sh "A14" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.4 -6.8
Sh "A15" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.2 -6.8
Sh "A16" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6 -6.8
Sh "A17" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.8 -6.8
Sh "A18" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.8 -6
Sh "B1" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6 -6
Sh "B2" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.2 -6
Sh "B3" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.4 -6
Sh "B4" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.6 -6
Sh "B5" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.8 -6
Sh "B6" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2 -6
Sh "B7" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.2 -6
Sh "B8" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.4 -6
Sh "B9" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.4 -6
Sh "B10" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.2 -6
Sh "B11" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2 -6
Sh "B12" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.8 -6
Sh "B13" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.6 -6
Sh "B14" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.4 -6
Sh "B15" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.2 -6
Sh "B16" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6 -6
Sh "B17" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.8 -6
Sh "B18" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.8 -5.2
Sh "C1" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6 -5.2
Sh "C2" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.2 -5.2
Sh "C3" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.4 -5.2
Sh "C4" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.6 -5.2
Sh "C5" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.8 -5.2
Sh "C6" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2 -5.2
Sh "C7" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.2 -5.2
Sh "C8" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.4 -5.2
Sh "C9" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.4 -5.2
Sh "C10" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.2 -5.2
Sh "C11" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2 -5.2
Sh "C12" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.8 -5.2
Sh "C13" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.6 -5.2
Sh "C14" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.4 -5.2
Sh "C15" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.2 -5.2
Sh "C16" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6 -5.2
Sh "C17" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.8 -5.2
Sh "C18" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.8 -4.4
Sh "D1" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6 -4.4
Sh "D2" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.2 -4.4
Sh "D3" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.4 -4.4
Sh "D4" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.6 -4.4
Sh "D5" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.8 -4.4
Sh "D6" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2 -4.4
Sh "D7" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.2 -4.4
Sh "D8" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.4 -4.4
Sh "D9" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.4 -4.4
Sh "D10" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.2 -4.4
Sh "D11" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2 -4.4
Sh "D12" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.8 -4.4
Sh "D13" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.6 -4.4
Sh "D14" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.4 -4.4
Sh "D15" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.2 -4.4
Sh "D16" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6 -4.4
Sh "D17" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.8 -4.4
Sh "D18" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.8 -3.6
Sh "E1" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6 -3.6
Sh "E2" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.2 -3.6
Sh "E3" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.4 -3.6
Sh "E4" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.6 -3.6
Sh "E5" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.8 -3.6
Sh "E6" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2 -3.6
Sh "E7" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.2 -3.6
Sh "E8" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.4 -3.6
Sh "E9" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.4 -3.6
Sh "E10" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.2 -3.6
Sh "E11" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2 -3.6
Sh "E12" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.8 -3.6
Sh "E13" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.6 -3.6
Sh "E14" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.4 -3.6
Sh "E15" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.2 -3.6
Sh "E16" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6 -3.6
Sh "E17" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.8 -3.6
Sh "E18" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.8 -2.8
Sh "F1" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6 -2.8
Sh "F2" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.2 -2.8
Sh "F3" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.4 -2.8
Sh "F4" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.6 -2.8
Sh "F5" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.8 -2.8
Sh "F6" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2 -2.8
Sh "F7" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.2 -2.8
Sh "F8" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.4 -2.8
Sh "F9" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.4 -2.8
Sh "F10" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.2 -2.8
Sh "F11" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2 -2.8
Sh "F12" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.8 -2.8
Sh "F13" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.6 -2.8
Sh "F14" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.4 -2.8
Sh "F15" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.2 -2.8
Sh "F16" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6 -2.8
Sh "F17" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.8 -2.8
Sh "F18" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.8 -2
Sh "G1" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6 -2
Sh "G2" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.2 -2
Sh "G3" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.4 -2
Sh "G4" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.6 -2
Sh "G5" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.8 -2
Sh "G6" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2 -2
Sh "G7" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.2 -2
Sh "G8" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.4 -2
Sh "G9" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.4 -2
Sh "G10" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.2 -2
Sh "G11" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2 -2
Sh "G12" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.8 -2
Sh "G13" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.6 -2
Sh "G14" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.4 -2
Sh "G15" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.2 -2
Sh "G16" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6 -2
Sh "G17" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.8 -2
Sh "G18" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.8 -1.2
Sh "H1" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6 -1.2
Sh "H2" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.2 -1.2
Sh "H3" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.4 -1.2
Sh "H4" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.6 -1.2
Sh "H5" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.8 -1.2
Sh "H6" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2 -1.2
Sh "H7" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.2 -1.2
Sh "H8" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.4 -1.2
Sh "H9" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.4 -1.2
Sh "H10" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.2 -1.2
Sh "H11" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2 -1.2
Sh "H12" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.8 -1.2
Sh "H13" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.6 -1.2
Sh "H14" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.4 -1.2
Sh "H15" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.2 -1.2
Sh "H16" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6 -1.2
Sh "H17" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.8 -1.2
Sh "H18" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.8 -0.4
Sh "J1" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6 -0.4
Sh "J2" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.2 -0.4
Sh "J3" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.4 -0.4
Sh "J4" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.6 -0.4
Sh "J5" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.8 -0.4
Sh "J6" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2 -0.4
Sh "J7" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.2 -0.4
Sh "J8" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.4 -0.4
Sh "J9" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.4 -0.4
Sh "J10" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.2 -0.4
Sh "J11" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2 -0.4
Sh "J12" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.8 -0.4
Sh "J13" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.6 -0.4
Sh "J14" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.4 -0.4
Sh "J15" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.2 -0.4
Sh "J16" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6 -0.4
Sh "J17" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.8 -0.4
Sh "J18" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.8 0.4
Sh "K1" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6 0.4
Sh "K2" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.2 0.4
Sh "K3" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.4 0.4
Sh "K4" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.6 0.4
Sh "K5" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.8 0.4
Sh "K6" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2 0.4
Sh "K7" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.2 0.4
Sh "K8" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.4 0.4
Sh "K9" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.4 0.4
Sh "K10" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.2 0.4
Sh "K11" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2 0.4
Sh "K12" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.8 0.4
Sh "K13" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.6 0.4
Sh "K14" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.4 0.4
Sh "K15" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.2 0.4
Sh "K16" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6 0.4
Sh "K17" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.8 0.4
Sh "K18" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.8 1.2
Sh "L1" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6 1.2
Sh "L2" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.2 1.2
Sh "L3" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.4 1.2
Sh "L4" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.6 1.2
Sh "L5" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.8 1.2
Sh "L6" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2 1.2
Sh "L7" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.2 1.2
Sh "L8" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.4 1.2
Sh "L9" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.4 1.2
Sh "L10" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.2 1.2
Sh "L11" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2 1.2
Sh "L12" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.8 1.2
Sh "L13" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.6 1.2
Sh "L14" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.4 1.2
Sh "L15" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.2 1.2
Sh "L16" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6 1.2
Sh "L17" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.8 1.2
Sh "L18" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.8 2
Sh "M1" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6 2
Sh "M2" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.2 2
Sh "M3" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.4 2
Sh "M4" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.6 2
Sh "M5" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.8 2
Sh "M6" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2 2
Sh "M7" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.2 2
Sh "M8" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.4 2
Sh "M9" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.4 2
Sh "M10" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.2 2
Sh "M11" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2 2
Sh "M12" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.8 2
Sh "M13" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.6 2
Sh "M14" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.4 2
Sh "M15" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.2 2
Sh "M16" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6 2
Sh "M17" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.8 2
Sh "M18" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.8 2.8
Sh "N1" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6 2.8
Sh "N2" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.2 2.8
Sh "N3" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.4 2.8
Sh "N4" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.6 2.8
Sh "N5" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.8 2.8
Sh "N6" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2 2.8
Sh "N7" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.2 2.8
Sh "N8" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.4 2.8
Sh "N9" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.4 2.8
Sh "N10" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.2 2.8
Sh "N11" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2 2.8
Sh "N12" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.8 2.8
Sh "N13" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.6 2.8
Sh "N14" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.4 2.8
Sh "N15" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.2 2.8
Sh "N16" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6 2.8
Sh "N17" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.8 2.8
Sh "N18" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.8 3.6
Sh "P1" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6 3.6
Sh "P2" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.2 3.6
Sh "P3" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.4 3.6
Sh "P4" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.6 3.6
Sh "P5" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.8 3.6
Sh "P6" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2 3.6
Sh "P7" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.2 3.6
Sh "P8" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.4 3.6
Sh "P9" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.4 3.6
Sh "P10" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.2 3.6
Sh "P11" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2 3.6
Sh "P12" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.8 3.6
Sh "P13" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.6 3.6
Sh "P14" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.4 3.6
Sh "P15" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.2 3.6
Sh "P16" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6 3.6
Sh "P17" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.8 3.6
Sh "P18" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.8 4.4
Sh "R1" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6 4.4
Sh "R2" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.2 4.4
Sh "R3" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.4 4.4
Sh "R4" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.6 4.4
Sh "R5" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.8 4.4
Sh "R6" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2 4.4
Sh "R7" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.2 4.4
Sh "R8" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.4 4.4
Sh "R9" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.4 4.4
Sh "R10" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.2 4.4
Sh "R11" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2 4.4
Sh "R12" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.8 4.4
Sh "R13" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.6 4.4
Sh "R14" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.4 4.4
Sh "R15" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.2 4.4
Sh "R16" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6 4.4
Sh "R17" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.8 4.4
Sh "R18" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.8 5.2
Sh "T1" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6 5.2
Sh "T2" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.2 5.2
Sh "T3" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.4 5.2
Sh "T4" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.6 5.2
Sh "T5" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.8 5.2
Sh "T6" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2 5.2
Sh "T7" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.2 5.2
Sh "T8" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.4 5.2
Sh "T9" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.4 5.2
Sh "T10" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.2 5.2
Sh "T11" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2 5.2
Sh "T12" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.8 5.2
Sh "T13" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.6 5.2
Sh "T14" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.4 5.2
Sh "T15" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.2 5.2
Sh "T16" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6 5.2
Sh "T17" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.8 5.2
Sh "T18" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.8 6
Sh "U1" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6 6
Sh "U2" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.2 6
Sh "U3" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.4 6
Sh "U4" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.6 6
Sh "U5" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.8 6
Sh "U6" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2 6
Sh "U7" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.2 6
Sh "U8" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.4 6
Sh "U9" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.4 6
Sh "U10" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.2 6
Sh "U11" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2 6
Sh "U12" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.8 6
Sh "U13" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.6 6
Sh "U14" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.4 6
Sh "U15" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.2 6
Sh "U16" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6 6
Sh "U17" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.8 6
Sh "U18" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.8 6.8
Sh "V1" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6 6.8
Sh "V2" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.2 6.8
Sh "V3" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.4 6.8
Sh "V4" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.6 6.8
Sh "V5" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.8 6.8
Sh "V6" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2 6.8
Sh "V7" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.2 6.8
Sh "V8" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.4 6.8
Sh "V9" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.4 6.8
Sh "V10" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.2 6.8
Sh "V11" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2 6.8
Sh "V12" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.8 6.8
Sh "V13" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.6 6.8
Sh "V14" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.4 6.8
Sh "V15" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.2 6.8
Sh "V16" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6 6.8
Sh "V17" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.8 6.8
Sh "V18" C 0.41 0.41 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$EndMODULE BGA324C80P18X18_1500X1500X150
$EndLIBRARY
